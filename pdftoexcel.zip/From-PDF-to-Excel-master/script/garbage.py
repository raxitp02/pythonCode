''' garbage scripts to keep '''

# To keep
# number = re.compile(r'(([-]\s+)?(\d+[ ])?\d+[.]\d+)')	# regular expression of the numer such as -123 456.00
# grossprofit = re.compile(r'Gross Profit((\s)+?([-]\s+)?(\d+[ ])?\d+[.]\d+)') # regular expression of the gross profit
# df = df.append(df2)	#append another dataframe
# current_directory = os.getcwd() #current working directory

# text = grapLastPagePDF(path)	# content of the last page
# df = transformToDf(text)		# to a df
# df.to_excel('from_PDF_to_XLSX.xlsx', sheet_name='sheet1', index=False) #parse into excel

## list of file in folder
# listePDF = os.listdir(PDFdirectory)
# print("liste of PDF", listePDF , "\n")