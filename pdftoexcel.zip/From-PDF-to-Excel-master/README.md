# From-PDF-to-Excel
==

Python script to copy some content of a PDF to Excel,
using PypPDF2, pandas and re

In the python script, we are concerned only with the first column of the PDF to copy (EUR)
