def stringRev (word):
     worLen = len(word)
     if worLen == 1:
         return word
     return [word[-1]] + stringRev(word[:-1])
 
 listWord = ["hey", "there", "Raxit"]
 print(stringRev(listWord))